from project.elf import ELf


class MuseElf(Elf):
    pass