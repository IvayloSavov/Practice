from project.product import Product


class Food(Product):
    __name: str
    __price: float
    __grams: float

    def __init__(self, name: str, price: float, grams: float):
        super().__init__(name, price)
        self.__grams = grams

    @property
    def grams(self):
        return self.__grams
